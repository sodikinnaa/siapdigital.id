PROMPT GENERATOR

Dua generator: ChatGPT (index.html) dan Claude (claude.html).
Tampilan CSS dan logika generator dipertahankan. Identitas, metadata situs, tautan kontak, dan navigasi merek lama dihapus.

Cara menjalankan yang disarankan:
1. Ekstrak ZIP.
2. Buka terminal di folder prompt-generator.
3. Jalankan: python3 -m http.server 8000
4. Buka http://localhost:8000 di browser.

Tanpa instalasi paket atau API key. Bisa diunggah ke hosting statis.
Membuka index.html langsung dapat membatasi clipboard dan penyimpanan lintas halaman, tergantung browser. Gunakan server lokal untuk fungsi lengkap.
Data disimpan hanya di browser. AI, audio, dan video diproses terpisah di layanan pilihan pengguna.
